﻿using Microsoft.UI.Xaml.Media;
using Microsoft.UI;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Diagnostics;
using RPISVR_Managements.Model;
using Google.Protobuf.WellKnownTypes;
using Microsoft.UI.Xaml.Media.Imaging;
using System.Collections.ObjectModel;
using MySql.Data.MySqlClient;

namespace RPISVR_Managements.ViewModel
{
    public class AdditioinInformationViewModel: INotifyPropertyChanged
    {
        //Database
        private readonly DatabaseConnection _dbConnection;
        

        //Command
        public ICommand SubmitCommand_Add_Information { get; }
        public ICommand ClearCommand { get; }



        public AdditioinInformationViewModel()
        {
            //Database 
            _dbConnection = new DatabaseConnection();
            //Submit Command
            SubmitCommand_Add_Information = new RelayCommand(async () => await SubmitAsync_Education_Levels());
            //Clear Command
            ClearCommand = new RelayCommand(async () => await ClearAsync());
            //Load Data to ListView
            LoadEducation_Levels();
            //Data to ListView
            Education_Level_ListView = new ObservableCollection<Education_Levels>();

            
        }

        //Education_Level_ID
        private string _edu_level_id;
        public string Edu_Level_ID
        {
            get => _edu_level_id;
            set
            {
                if (_edu_level_id != value)
                {
                    _edu_level_id = value;
                    OnPropertyChanged(nameof(Edu_Level_ID));
                }
            }
        }
        //Education_Level_Name_KH
        private string _edu_levevl_name_kh;
        public string Edu_Level_Name_KH
        {
            get => _edu_levevl_name_kh;
            set
            {
                if (_edu_levevl_name_kh != value)
                {
                    _edu_levevl_name_kh = value;
                    OnPropertyChanged(nameof(Edu_Level_Name_KH));
                }
            }
        }
        //Education_Level_Name_EN
        private string _edu_level_name_en;
        public string Edu_Level_Name_EN
        {
            get => _edu_level_name_en;
            set
            {
                if(_edu_level_name_en != value)
                {
                    _edu_level_name_en = value;
                    OnPropertyChanged(nameof(Edu_Level_Name_EN));
                }
            }
        }
        //Education_Level_Name_Short
        private string _edu_level_name_short;
        public string Edu_Level_Name_Short
        {
            get => _edu_level_name_short;
            set
            {
                if(_edu_level_name_short != value)
                {
                    _edu_level_name_short = value;
                    OnPropertyChanged(nameof(Edu_Level_Name_Short));
                }
            }
        }

        //Edu_Error_Message
        private string _Edu_Error_Message;
        public string Edu_Error_Message
        {
            get => _Edu_Error_Message;
            set
            {
                _Edu_Error_Message = value;
                OnPropertyChanged(nameof(Edu_Error_Message));
            }
        }
        //ValidateEdu_Level_ID
        private void ValidateEdu_Level_ID()
        {
            if (string.IsNullOrEmpty(Edu_Level_ID))
            {
                Edu_Error_Message = "សូមបញ្ចូលលេខសម្គាល់ កម្រិតសិក្សា";     
            }
            else
            {
                Edu_Error_Message = "";
                Debug.WriteLine($"Edu_Level_ID = {Edu_Level_ID}");
            }
        }
        //ValidateEdu_Level_Name_KH
        private void ValidateEdu_Level_Name_KH()
        {
            if (string.IsNullOrEmpty(Edu_Level_Name_KH))
            {
                Edu_Error_Message = "សូមបញ្ចូលឈ្មោះ កម្រិតសិក្សា";
            }
            else
            {
                Edu_Error_Message = "";
                Debug.WriteLine($"Edu_Level_Name_KH = {Edu_Level_Name_KH}");
            }
        }
        //SaveStudentInformationtoDatabase
        public void Save_Education_Levels()
        {
            DatabaseConnection dbConnection = new DatabaseConnection();

            Education_Levels education_info = new Education_Levels
            {
                Edu_Level_ID = this.Edu_Level_ID,
                Edu_Level_Name_KH = this.Edu_Level_Name_KH,
                Edu_Level_Name_EN = this.Edu_Level_Name_EN,
                Edu_Level_Name_Short = this.Edu_Level_Name_Short,
            };
            bool success = dbConnection.Insert_Education_Levels(education_info);

            if (success)
            {
                Edu_Error_Message = "ទិន្នន័យបានរក្សាទុកជោគជ័យ";
            }
            else
            {
                Edu_Error_Message = "ទិន្នន័យមិនបានរក្សាទុកជោគជ័យ !";
            }
        }

        public async Task SubmitAsync_Education_Levels()
        {
           ValidateEdu_Level_ID();
           ValidateEdu_Level_Name_KH();

                Debug.WriteLine("Insert Mode");
                Debug.WriteLine(Edu_Level_ID);
                Debug.WriteLine(Edu_Level_Name_KH);
                Debug.WriteLine(Edu_Level_Name_EN);
                Debug.WriteLine(Edu_Level_Name_Short);

            Save_Education_Levels();
            LoadEducation_Levels();
            Clear_Education_Level_Text();
            await Task.CompletedTask;
        }
        //
        public async Task ClearAsync()
        {
            Clear_Education_Level_Text();
        }
        //Method for Clear Text
        public void Clear_Education_Level_Text()
        {
            //_studentModel = new DatabaseConnection();
            //var (id, stu_ID) = _studentModel.Get_ID_and_Stu_ID();
            //Debug.WriteLine("New ID: " + ID);
            //Debug.WriteLine("New Stu_ID: " + stu_ID);
            //ID = id;
            Edu_Level_ID = string.Empty;
            Edu_Level_Name_KH = string.Empty;
            Edu_Level_Name_EN = string.Empty;
            Edu_Level_Name_Short = string.Empty;
        }

        //Method to get data to ListView
        //Data to ListView
        private ObservableCollection<Education_Levels> _education_level;
        public ObservableCollection<Education_Levels> Education_Level_ListView
        {
            get => _education_level;
            set
            {
                _education_level = value;
                OnPropertyChanged(nameof(Education_Level_ListView));  // Notify the UI when the Students collection changes
            }
        }
        //Load Education_Level
        private void LoadEducation_Levels()
        {
            // Ensure _dbConnection is properly initialized
            if (_dbConnection == null)
            {
                Debug.WriteLine("_dbConnection is not initialized.");
                return;
            }

            var education_level_list = _dbConnection.LoadEducation_Level();

            if (education_level_list != null && education_level_list.Count > 0)
            {
                // Clear the existing items in the ObservableCollection
                //Education_Level_ListView.Clear();

                // Add new items from the database
                foreach (var education_levels in education_level_list)
                {
                    Education_Level_ListView.Add(education_levels);
                }
            }
            else
            {
                Debug.WriteLine("No education levels found.");
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
