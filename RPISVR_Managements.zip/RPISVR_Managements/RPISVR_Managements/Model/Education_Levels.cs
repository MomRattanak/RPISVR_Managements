﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPISVR_Managements.Model
{
    public class Education_Levels
    {
        //public int ID { get; set; }
        public string Edu_Level_ID { get; set; }
        public string Edu_Level_Name_KH { get; set; }
        public string Edu_Level_Name_EN { get; set; }
        public string Edu_Level_Name_Short { get; set; } 
    }
}
