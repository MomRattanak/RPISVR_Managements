﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RPISVR_Managements.Model
{
    public class Education_Skills
    {
        public int ID { get; set; }
        public string Skill_ID { get; set; }
        public string Skill_Name_KH { get; set; }
        public string Skill_Name_EN { get; set; }
        public string Skill_Name_Short { get; set; }
    }
}
